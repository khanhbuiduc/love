'use client'

import React from 'react'
import { motion } from 'framer-motion'

const timelineEvents = [
  {
    id: 1,
    title: 'The Day We Met',
    description: 'The moment our worlds collided and everything changed',
    image: 'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=400&h=300&fit=crop',
    position: 'left',
  },
  {
    id: 2,
    title: 'Our First Date',
    description: 'Where we discovered that magic was real',
    image: 'https://images.unsplash.com/photo-1519671482677-504be0271101?w=400&h=300&fit=crop',
    position: 'right',
  },
  {
    id: 3,
    title: 'Our First Trip',
    description: 'Adventures shared under new skies',
    image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop',
    position: 'left',
  },
  {
    id: 4,
    title: 'Our Anniversary',
    description: 'The beginning of forever starts here',
    image: 'https://images.unsplash.com/photo-1469512169745-13a38328f41f?w=400&h=300&fit=crop',
    position: 'right',
  },
]

export const Timeline = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, x: (index: number) => (index % 2 === 0 ? -50 : 50) },
    visible: {
      opacity: 1,
      x: 0,
      transition: { duration: 0.6 },
    },
  }

  return (
    <section id="timeline" className="py-20 px-4 md:px-8 bg-gradient-to-b from-white via-pink-50 to-white">
      <div className="max-w-6xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-5xl md:text-6xl font-serif text-center mb-4 sakura-text text-balance"
        >
          Threads of Fate
        </motion.h2>
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-center text-gray-600 text-lg mb-16"
        >
          Our love story written in moments
        </motion.p>

        <div className="relative">
          {/* Timeline line */}
          <motion.div
            initial={{ scaleY: 0 }}
            whileInView={{ scaleY: 1 }}
            transition={{ duration: 1 }}
            className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-[#FFB7C5] via-[#9C89B8] to-[#F7A072]"
          />

          {/* Timeline events */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="space-y-12"
          >
            {timelineEvents.map((event, index) => (
              <motion.div
                key={event.id}
                variants={{
                  hidden: { opacity: 0, x: event.position === 'left' ? -50 : 50 },
                  visible: {
                    opacity: 1,
                    x: 0,
                    transition: { duration: 0.6 },
                  },
                }}
                className={`flex ${event.position === 'left' ? 'flex-row-reverse' : ''}`}
              >
                {/* Content */}
                <div className="w-1/2 px-8">
                  <motion.div
                    whileHover={{ y: -5 }}
                    className="glass-effect p-6 rounded-lg hover:shadow-lg hover:shadow-[#FFB7C5]/20 transition-all"
                  >
                    <h3 className="text-2xl font-serif text-[#1A1F3A] mb-2">{event.title}</h3>
                    <p className="text-gray-600 mb-4">{event.description}</p>
                    <div className="w-full h-32 rounded-lg overflow-hidden">
                      <img
                        src={event.image}
                        alt={event.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </motion.div>
                </div>

                {/* Timeline dot */}
                <div className="w-0 flex justify-center">
                  <motion.div
                    animate={{ scale: [1, 1.3, 1] }}
                    transition={{ duration: 2, repeat: Infinity, delay: index * 0.2 }}
                    className="w-5 h-5 rounded-full bg-gradient-to-r from-[#FFB7C5] to-[#F7A072] border-4 border-white shadow-lg shadow-[#FFB7C5]/50"
                  />
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  )
}
