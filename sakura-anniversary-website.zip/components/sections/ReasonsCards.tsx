'use client'

import React from 'react'
import { motion } from 'framer-motion'
import { Heart, Sparkles, Music, Sunset, Star, Flame } from 'lucide-react'

const reasons = [
  {
    id: 1,
    title: 'Your Kindness',
    description: 'The way you care for others makes my heart overflow',
    icon: Heart,
  },
  {
    id: 2,
    title: 'Your Laughter',
    description: 'Your smile lights up my darkest days',
    icon: Sparkles,
  },
  {
    id: 3,
    title: 'Our Moments',
    description: 'Every moment together feels like a song',
    icon: Music,
  },
  {
    id: 4,
    title: 'Your Dreams',
    description: 'I believe in you more than anyone ever could',
    icon: Sunset,
  },
  {
    id: 5,
    title: 'Your Strength',
    description: 'You inspire me to be better every single day',
    icon: Star,
  },
  {
    id: 6,
    title: 'Your Love',
    description: 'The way you love me changes everything',
    icon: Flame,
  },
]

export const ReasonsCards = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  }

  return (
    <section className="py-20 px-4 md:px-8 bg-gradient-to-b from-pink-50 to-purple-50">
      <div className="max-w-6xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-5xl md:text-6xl font-serif text-center mb-4 sakura-text text-balance"
        >
          Blossom Cards
        </motion.h2>
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-center text-gray-600 text-lg mb-16"
        >
          Reasons why you're my everything
        </motion.p>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {reasons.map((reason, index) => {
            const Icon = reason.icon
            return (
              <motion.div
                key={reason.id}
                variants={cardVariants}
                whileHover={{
                  y: -8,
                  boxShadow: '0 20px 40px rgba(255, 183, 197, 0.3)',
                }}
                className="glass-effect p-8 rounded-lg border-2 border-white/20 hover:border-[#FFB7C5] transition-all duration-300 group"
              >
                <motion.div
                  whileHover={{ rotate: 360, scale: 1.2 }}
                  transition={{ duration: 0.6 }}
                  className="w-16 h-16 rounded-full bg-gradient-to-br from-[#FFB7C5] to-[#F7A072] flex items-center justify-center mb-4 group-hover:shadow-lg group-hover:shadow-[#FFB7C5]/50"
                >
                  <Icon className="w-8 h-8 text-white" />
                </motion.div>

                <h3 className="text-2xl font-serif text-[#1A1F3A] mb-2">{reason.title}</h3>
                <p className="text-gray-600">{reason.description}</p>

                <motion.div
                  animate={{ opacity: [0, 1, 0] }}
                  transition={{ duration: 2, repeat: Infinity, delay: index * 0.2 }}
                  className="mt-4 h-1 bg-gradient-to-r from-[#FFB7C5] to-transparent rounded-full"
                />
              </motion.div>
            )
          })}
        </motion.div>
      </div>
    </section>
  )
}
