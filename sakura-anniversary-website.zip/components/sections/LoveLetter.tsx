'use client'

import React from 'react'
import { motion } from 'framer-motion'

export const LoveLetter = () => {
  return (
    <section className="py-20 px-4 md:px-8 bg-gradient-to-b from-white via-orange-50 to-white relative overflow-hidden">
      {/* Sunset glow background */}
      <motion.div
        animate={{ opacity: [0.2, 0.4, 0.2] }}
        transition={{ duration: 5, repeat: Infinity }}
        className="absolute inset-0 pointer-events-none bg-gradient-to-b from-[#F7A072]/20 to-[#FFB7C5]/20 blur-3xl"
      />

      <div className="max-w-2xl mx-auto relative z-10">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-5xl md:text-6xl font-serif text-center mb-12 sakura-text text-balance"
        >
          Sunset Confession
        </motion.h2>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          whileHover={{ y: -5 }}
          className="relative"
        >
          <div className="absolute inset-0 rounded-lg bg-gradient-to-br from-orange-100/50 via-pink-100/30 to-purple-100/20 blur-lg" />
          
          <div className="relative glass-effect p-12 rounded-lg shadow-2xl shadow-orange-200/30">
            {/* Letter texture */}
            <div className="absolute inset-0 rounded-lg opacity-5 bg-[url('data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"100\" height=\"100\"><defs><pattern id=\"pattern\" x=\"0\" y=\"0\" width=\"100\" height=\"100\" patternUnits=\"userSpaceOnUse\"><path d=\"M0 0L100 0L50 100\" fill=\"%23333\" opacity=\"0.1\"/></pattern></defs><rect width=\"100\" height=\"100\" fill=\"%23fff\" opacity=\"0.5\"/></svg>')]" />

            <div className="relative space-y-6 font-serif text-[#1A1F3A]">
              <motion.p
                animate={{ opacity: [0.8, 1, 0.8] }}
                transition={{ duration: 3, repeat: Infinity }}
                className="text-center text-sm text-[#9C89B8] tracking-widest mb-6"
              >
                ✦ A Letter to You ✦
              </motion.p>

              <p className="text-lg leading-relaxed">
                My dearest,
              </p>

              <p className="text-lg leading-relaxed">
                There are moments in life that change everything. The moment I met you was one of those. In your eyes, I found a reflection of the person I wanted to become, and in your smile, I discovered what it truly means to love.
              </p>

              <p className="text-lg leading-relaxed">
                Every sunrise we've watched together, every journey we've taken, every quiet moment in between—they've all been chapters in a story I never want to end. You are my greatest adventure, my sweetest dream, and my forever home.
              </p>

              <p className="text-lg leading-relaxed">
                As we continue this journey together, know that every beat of my heart belongs to you. You are not just my love—you are my everything.
              </p>

              <p className="text-lg leading-relaxed">
                Forever yours,
              </p>

              <p className="text-center text-[#FFB7C5] font-bold text-xl pt-4">
                ♡
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
